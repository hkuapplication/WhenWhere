package cs.hku.hk.whenwhere.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import cs.hku.hk.whenwhere.R;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
    }
}
